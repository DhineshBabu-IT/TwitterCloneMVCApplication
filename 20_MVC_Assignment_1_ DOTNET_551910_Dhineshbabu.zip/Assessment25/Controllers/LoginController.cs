﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Text;
using System.Globalization;
using TwitterDataAccessLayer;

using Assessment25.Models;

namespace Assessment25.Controllers
{
    public class LoginController : Controller
    {
        private LoginDataAccessLayer loginDAL;
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SignIn(PersonModel model)
        {           
            loginDAL = new LoginDataAccessLayer();
            Person personModel = new Person();
            personModel.UserId = model.UserId;
            personModel.Pwd = model.PasswordHash;
            bool isValid = loginDAL.Validate(personModel);
            if (isValid)
            {
                FormsAuthentication.SetAuthCookie(model.UserId, true);
                return RedirectToAction("Dashboard", new { query = model.UserId });
            }
            ViewBag.Error = "Invalid Username or Password";
            
            return View("Login", model);
        }

        public ActionResult SignUp()
        {
            PersonModel model = new PersonModel();
            return View(model);
        }

        [HttpPost]
        public ActionResult SignUp(PersonModel model)
        {
            if (ModelState.IsValid)
            {
                loginDAL = new LoginDataAccessLayer();
                Person personModel = new Person();
                personModel.UserId = model.UserId;
                personModel.Pwd = model.PasswordHash;
                personModel.FullName = model.FullName;
                personModel.Email = model.Email;
                var result = loginDAL.SignUp(personModel);
                if (result == "Success")
                {
                    ViewBag.Message = "Registration Success";
                }
                else if (result == "Duplicate User")
                {
                    ViewBag.Error = "Provided Details are already exist";
                }
            }
            return View(model);
        }

        public ActionResult Dashboard(string query)
        {
            loginDAL = new LoginDataAccessLayer();
            DashboardModel dashModel = new DashboardModel();
            Dashboard dash = new Dashboard();
            dash = loginDAL.GetDashboardDetails(query);
            dash.TweetList = new List<Tweet>();
            dash.TweetList = loginDAL.GetAllTweets();

            dashModel.Following = dash.Following;
            dashModel.Followers = dash.Followers;
            dashModel.TweetCount = dash.TweetCount;
            dashModel.Person = new PersonModel
            {
                FullName = dash.Person.FullName,
                Id =dash.Person.UserId
            };
            dashModel.LoggedInUserId = dash.Person.UserId;
            TweetModel tweet = new TweetModel();
            dashModel.TweetList = new List<TweetModel>();
            dashModel.TweetList = MapTweets(dash.TweetList);
            return View(dashModel);
        }

        [HttpPost]
        public ActionResult PostTweet(DashboardModel model)
        {
            Tweet tweetModel = new Tweet();
            tweetModel.UserId = model.LoggedInUserId;
            tweetModel.Message = model.Message;
            loginDAL = new LoginDataAccessLayer();
            loginDAL.PostTweet(tweetModel);
            model.TweetList = new List<TweetModel>();
            model.TweetList = MapTweets(loginDAL.GetAllTweets());
            return View("_TweetList", model);
        }

        public ActionResult Error()
        {
            return View();
        }

        private List<TweetModel> MapTweets(List<Tweet> twList)
        {
            List<TweetModel> list = new List<TweetModel>();
            TweetModel tweet = new TweetModel();
            foreach (var obj in twList)
            {
                tweet.TweetUser = obj.UserId.ToUpper();
                tweet.TweetMessage = obj.Message;
                string dateFormat;
                if (obj.Created.Subtract(DateTime.Today).Days == 0)
                {
                    dateFormat = "h:mm tt";
                }
                else
                {
                    dateFormat = "dd MMM";
                }
                tweet.TweetTime = obj.Created.ToString(dateFormat);
                list.Add(tweet);
                tweet = new TweetModel();
            }
            return list;
        }

    }
}